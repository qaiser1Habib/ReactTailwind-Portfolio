function App() {
  return <div className="bg-amber-100">hello</div>;
}

export default App;
